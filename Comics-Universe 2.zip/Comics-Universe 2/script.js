// DATA
const comics = [
    
  {name:"Invincible",type:"indie",company:"Image Comics",year:"2003",image:"comic1.jpg",text:"A young hero learns what strength, responsibility, and real danger mean."},
  {name:"Shazam!",type:"dc",company:"DC Comics",year:"2023",image:"comic2.jpg",text:"Magic, humor, and big hero energy come together in a bright poster-style cover."},
  {name:"Spider-Man",type:"marvel",company:"Marvel Comics",year:"2020",image:"comic3.jpg",text:"One of the most recognizable comic heroes, always bringing motion and energy to the page."},
  {name:"Ben 10",type:"cartoon",company:"Cartoon Network",year:"2010",image:"comic4.jpg",text:"Aliens, green light, and action-cartoon chaos make this cover feel loud and fun."},
  {name:"Ninja Dude",type:"indie",company:"Mikey's Comics",year:"First Issue",image:"comic5.jpg",text:"A funny retro comic with pizza, attitude, and a playful underground poster look."},
  {name:"Adventure Time",type:"cartoon",company:"Kaboom!",year:"Issue 1",image:"comic6.jpg",text:"A soft and cheerful cartoon world with friendly colors and a lot of charm."},
  {name:"Lego Spider-Man",type:"marvel",company:"Lego Comics Group",year:"12C",image:"comic7.jpg",text:"Classic superhero movement mixed with a playful brick-built comic style."},
  {name:"Batman",type:"dc",company:"DC Comics",year:"Classic Poster",image:"comic8.jpg",text:"Dark shapes, strong contrast, and a huge moon create a dramatic and iconic poster."},
  {name:"Courage",type:"cartoon",company:"Cartoon Horror Style",year:"Retro Poster",image:"comic9.jpg",text:"A wild mix of spooky color, rough texture, and loud expression gives this cover a bold comic feel."}
];
const search = document.getElementById("search");

const likeCount = document.getElementById("likeCount");
const likeText = document.getElementById("likeText");

const modal = document.getElementById("modal");
const modalPic = document.getElementById("modalPic");
const modalName = document.getElementById("modalName");
const modalCompany = document.getElementById("modalCompany");
const modalText = document.getElementById("modalText");

const contactForm = document.getElementById("contactForm");
const note = document.getElementById("note");

// LIKES
let likes = JSON.parse(localStorage.getItem("likes")) || [];

// FILTER
let nowType = "all";

// CAROUSEL
let nowSlide = 0;

/*DARK MODE*/
const modeBtn = document.getElementById("modeBtn");
modeBtn.addEventListener("click", function (){
    document.body.classList.toggle("dark");
    if(document.body.classList.contains("dark")){
        modeBtn.textContent = "Light Mode";
    }else{
        modeBtn.textContent = "Dark Mode";
    }
});


/*CAROUSEL*/
function showSlide(){
    if(!document.getElementById("slidePic")) return;
    slidePic.src = comics[nowSlide].image;
    slideName.textContent = comics[nowSlide].name;
    slideCompany.textContent =
    comics[nowSlide].company + " • " + comics[nowSlide].year;
    slideText.textContent =
    comics[nowSlide].text;
}
function nextSlide(){
    nowSlide++;
    if(nowSlide >= comics.length){
        nowSlide = 0;}showSlide();}
function prevSlide(){
    nowSlide--;
    if(nowSlide < 0){
        nowSlide = comics.length - 1;}showSlide();}




/*LIKES*/
function showLikesInfo(){
    if(!likeCount) return;
    likeCount.textContent = likes.length;
    if(likes.length == 0){
        likeText.textContent = "No liked comics yet.";
    }else{
        likeText.textContent =
        "Liked comics: " + likes.join(", ");}}
function toggleLike(name){
    if(likes.includes(name)){
        likes = likes.filter(item => item != name);
    }else{
        likes.push(name);
    }
    localStorage.setItem(
        "likes",
        JSON.stringify(likes)
    );
    drawComics();
    showLikesInfo();}

/*MODAL*/
function openModal(i){
    modalPic.src = comics[i].image;
    modalName.textContent = comics[i].name;
    modalCompany.textContent =
    comics[i].company + " • " + comics[i].year;
    modalText.textContent = comics[i].text;
    modal.classList.add("show");}
function closeModal(){
    modal.classList.remove("show");}



/*SEARCH AND FILTER*/
function drawComics(){
    const comicList =
    document.getElementById("comicList");
    if(!comicList) return;
    const text =
    search.value.toLowerCase();
    const filtered = comics.filter(comic =>
        (nowType == "all" ||
         comic.type == nowType) &&
        comic.name.toLowerCase().includes(text)
    );
    comicList.innerHTML = "";
    filtered.forEach(comic => {
        const i = comics.indexOf(comic);
        comicList.innerHTML += `
        <article class="card">
            <img class="pic"
            src="${comic.image}">

            <div class="in">
                <h3>${comic.name}</h3>

                <p class="small">
                ${comic.company}
                </p>

                <p>${comic.text}</p>

                <div class="card-row">

                    <button
                    class="small-btn"
                    onclick="openModal(${i})">
                    Open Modal
                    </button>

                    <button
                    class="small-btn"
                    onclick="toggleLike('${comic.name}')">

                    ${likes.includes(comic.name)
                    ? "Remove Like"
                    : "Add Like"}

                    </button>
                </div>
            </div>
        </article>
        `;
    });
}
function setType(type){
    nowType = type;
    drawComics();}

/*CONTACT FORM*/
if(contactForm){
    contactForm.onsubmit = function(e){
        e.preventDefault();
        if(
            name.value == "" ||
            email.value == "" ||
            message.value == ""
        ){
            note.textContent =
            "Please fill in all fields.";
            return;}
        note.textContent =
        "Message sent.";
        contactForm.reset();}}


/*START*/
if(search){
    search.oninput = drawComics;
    drawComics();
    showLikesInfo();
}

if(modal){
    modal.onclick = function(e){
        if(e.target == modal){
            closeModal();
        }
    }
}

showSlide();